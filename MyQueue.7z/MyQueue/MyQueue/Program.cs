﻿using LibraryMyQueue.Helper;
using LibraryMyQueue.Logic;
using System;
using static System.Console;

namespace MyQueue
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            bool isCancel = true;
            int index = 0;
            Helpers.ShowFirstInformation();

            MyQueue<Person> pilist = null;

            try
            {
                while (isCancel)
                {
                    WriteLine("Выберите вариант использования:");

                    switch (Helpers.InputControl())
                    {
                        case 0:
                            pilist = new MyQueue<Person>();

                            pilist.GetNumbers = Helpers.GetPhoneCount();

                            for (int i = 0; i < 5; i++)
                            {
                                WriteLine("Введите номер телефона №{0}:", i + 1);  
                                
                                pilist.Add(new Person(i, Helpers.IsCorrectInput()));

                                index += i;
                            }
                            WriteLine(pilist.ToString());
                            break;
                        case 1:
                            if (!Helpers.IsEmptyObject(pilist))
                            {
                                pilist.GetNumbers = Helpers.GetPhoneCount();

                                pilist.dequeue();

                                WriteLine(pilist.ToString());
                            }
                            break;
                        case 2:
                            if (!Helpers.IsEmptyObject(pilist))
                            {
                                pilist.GetNumbers = Helpers.GetPhoneCount();

                                WriteLine("Введите номер телефона:");

                                pilist.enqueue(new Person(index, Helpers.IsCorrectInput()));

                                index++;

                                WriteLine(pilist.ToString());
                            }
                            break;
                        case 3:
                            if (!Helpers.IsEmptyObject(pilist))
                            {
                                pilist.GetNumbers = Helpers.GetPhoneCount();

                                WriteLine(pilist.isEmpty());
                            }
                            break;
                        case 4:
                            if (!Helpers.IsEmptyObject(pilist))
                            {
                                pilist.GetNumbers = Helpers.GetPhoneCount();

                                WriteLine(pilist.size());
                            }
                            break;
                        case 5:
                            if (!Helpers.IsEmptyObject(pilist))
                            {
                                pilist.GetNumbers = Helpers.GetPhoneCount();

                                pilist.sortByID();

                                WriteLine(pilist.ToString());
                            }
                            break;
                        case 6:
                            if (!Helpers.IsEmptyObject(pilist))
                            {
                                pilist.GetNumbers = Helpers.GetPhoneCount();

                                pilist.sortByPhoneNumber();

                                WriteLine(pilist.ToString());
                            }
                            break;
                        default:
                            if (!Helpers.IsEmptyObject(pilist))
                            {
                                WriteLine(pilist.ToString());
                            }

                            break;
                    }

                    WriteLine("Для завершения нажмите ESC или нажмите Enter:");

                    isCancel = ReadKey(true).Key != ConsoleKey.Escape;
                }
                Environment.Exit(0);
            }
            catch (NotFoundException)
            {
                WriteLine("Error");
            }
        }
    }
}
