﻿namespace LibraryMyQueue.Interface
{  
    public interface IPerson
        {
        int id { get; set; }
        int phoneNumber { get; set; }
    }   
}
