﻿using LibraryMyQueue.Interface;
namespace LibraryMyQueue.Logic
{    
    public class Person : IPerson
    {
        public Person(int n, int num)
        {
            id = n;
            phoneNumber = num;         
        }       
        public int id { get; set; }
        public int phoneNumber { get; set; }       
    }  
}
