﻿using LibraryMyQueue.Interface;
using System;

namespace LibraryMyQueue.Logic
{
    public class MyQueue<T> where T : IPerson
    {
        private readonly T[] phList;
        private int end;
        private readonly int number;
        public MyQueue()
        {
            phList = new T[5];
            end = 0;
        }      

        public int GetNumbers { get; set; }
        public bool Add(T newEntry)
        {
            if (end == 5)
            {
                return false;
            }

            phList[end] = newEntry;
            end++;
            return true;
        }
        public T dequeue()
        {
            T varPhList;
            if (phList[0] != null)
            {
                varPhList = phList[0];
            }
            else { throw new NotFoundException(); }

            T[] phListClone = new T[end];
            phListClone = (T[])phList.Clone();
            for (int i = 0; i < end - 1; i++)
            {
                phList[i] = phListClone[i + 1];
            }
            phList[end - 1] = default(T);

            return varPhList;
        }
        public void enqueue(T newEntry)
        {
            phList[end - 1] = newEntry;
        }
        public bool isEmpty()
        {
            return size() > 0 ? false : true;
        }
        public int size()
        {
            return phList.Length;
        }
        public void sortByID()
        {
            T temp;
            for (int i = 0; i < phList.Length; i++)
            {
                for (int j = i + 1; j < phList.Length; j++)
                {
                    if (phList[i].id > phList[j].id)
                    {
                        temp = phList[i];
                        phList[i] = phList[j];
                        phList[j] = temp;
                    }
                }
            }
        }
        public void sortByPhoneNumber()
        {
            T temp;
            for (int i = 0; i < phList.Length; i++)
            {
                for (int j = i + 1; j < phList.Length; j++)
                {
                    if (phList[i].phoneNumber > phList[j].phoneNumber)
                    {
                        temp = phList[i];
                        phList[i] = phList[j];
                        phList[j] = temp;
                    }
                }
            }
        }
        public override string ToString()
        {
            string result = string.Empty;

            if (isEmpty())
            {
                return result;
            }
            else
            {
                for (int i = 0; i < end; i++)
                {
                    result +=GetNumbers>i && phList[i]!=null? string.Format("+{0} ", phList[i].phoneNumber): string.Format("{0} ", String.Empty);
                }
            }
            return result;
        }
    }

    public class NotFoundException : Exception
    {
        public NotFoundException() : base() { }
        public NotFoundException(string str) : base(str) { }
        public NotFoundException(
             string str, Exception inner) : base(str, inner) { }
        protected NotFoundException(
          System.Runtime.Serialization.SerializationInfo si,
          System.Runtime.Serialization.StreamingContext sc) : base(si, sc) { }
    }
}