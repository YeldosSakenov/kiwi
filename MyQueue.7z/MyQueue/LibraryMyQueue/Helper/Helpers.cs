﻿using LibraryMyQueue.Logic;
using static System.Console;

namespace LibraryMyQueue.Helper
{
    public static class Helpers
    {
        public static int InputControl()
        {
            string line = ReadLine();

            if (int.TryParse(line, out int value))
            {
                return value;
            }
            else
            {
                WriteLine("Введенное значение не верно");
                return -1;
            }
        }

        public static void ShowFirstInformation()
        {
            WriteLine("Варианты использования:");
            WriteLine("-----------------------");
            WriteLine("Ввод данных: 0");
            WriteLine("Dequeue: 1");
            WriteLine("Enqueue: 2");
            WriteLine("isEmpty: 3");
            WriteLine("size: 4");
            WriteLine("sortByID: 5");
            WriteLine("sortByPhoneNumber: 6");
            WriteLine("-----------------------");
        }

        public static bool IsEmptyObject(MyQueue<Person> pilist)
        {
            if (pilist == null)
            {
                WriteLine("Очередь пуста");
                return true;
            }
            else
            {
                return
                    false;
            }
        }

        public static int IsCorrectInput()
        {           
            bool insert = true;
            int number=0;
            while (insert)
            {
                number = InputControl();
                if (number > 0)
                {                   
                    insert = false;
                }
            }
            return number;
        }

        public static int GetPhoneCount()
        {
            WriteLine("Введите требуемое значение номеров:");
            return IsCorrectInput();
        }
    }
}
